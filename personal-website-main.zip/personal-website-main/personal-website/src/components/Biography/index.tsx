import Biography from './Biography'

export default Biography
