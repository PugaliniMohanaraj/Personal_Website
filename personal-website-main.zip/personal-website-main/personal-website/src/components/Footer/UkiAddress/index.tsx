import UkiAddress from './UkiAddress'

export default UkiAddress
