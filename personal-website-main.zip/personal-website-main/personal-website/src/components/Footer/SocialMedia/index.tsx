import SocialMedia from './SocialMedia'

export default SocialMedia

