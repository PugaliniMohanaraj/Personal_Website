import UkiLogo from './UkiLogo'

export default UkiLogo
