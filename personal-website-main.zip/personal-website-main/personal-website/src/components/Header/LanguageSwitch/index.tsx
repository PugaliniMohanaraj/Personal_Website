import LanguageSwitch from './LanguageSwitch'

export default LanguageSwitch
