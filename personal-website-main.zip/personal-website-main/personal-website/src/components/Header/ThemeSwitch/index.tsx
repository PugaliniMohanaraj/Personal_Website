import ThemeSwitch from './ThemeSwitch'

export default ThemeSwitch
